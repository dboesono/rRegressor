## ---- include = FALSE---------------------------------------------------------
# knitr::opts_chunk$set(
#   collapse = TRUE,
#   comment = "#>"
# )
knitr::opts_chunk$set(
  fig.align = 'center',
  fig.path = 'webimg/',
  fig.width = 7,
  fig.height = 7,
  out.width = '500px',
  dev = 'png')
library(magrittr)

## ---- eval = FALSE------------------------------------------------------------
#  install.packages("/path/to/rRegressor_0.1.0.tar.gz", repos = NULL, type = "source")

## ----setup--------------------------------------------------------------------
library(rRegressor)

## ---- eval = FALSE------------------------------------------------------------
#  data("boston_df")

## -----------------------------------------------------------------------------
head(boston_df)

## ---- message = FALSE, warning = FALSE, results='hide'------------------------
boston_df %>%  
  plot_correlation_matrix(.,title = "Boston Housing Dataset Correlation Matrix", 
                          size_coercoef = 0.7)

## -----------------------------------------------------------------------------
# Fit a linear regression model
lm_fit <- boston_df[1:10,] %>% fit_linear_regression(., x_vars = c("age", "rm", "lstat"), 
                                                     y_var = "medv")

# Display the model object
lm_fit$model

# Display the fitted values
lm_fit$fitted_values

## -----------------------------------------------------------------------------
# Fit and predict a linear regression model
lm_pred = boston_df[1:10,] %>% fit_linear_regression(.,
                                                     x_vars = c("age","rm","lstat"), 
                                                     y_var = "medv") %>% 
  predict_linear_regression(data = boston_df[40:50,],
                            lm_fit = .,
                            x_vars = c("age","rm","lstat"))

#Display the predicted values
lm_pred

## -----------------------------------------------------------------------------
# Fit a Ridge regression model using the 'rm' (number of rooms) and 'lstat' (percent of lower status of the population) variables as predictors
ridge_fit <- boston_df[1:10,] %>%  fit_ridge_regression(., 
                                                        x_vars = c("rm", "lstat"), 
                                                        y_var = "medv", 
                                                        lambda = 0.1)

# Display the model object
ridge_fit$model

# Display the fitted values
ridge_fit$fitted_values


## -----------------------------------------------------------------------------
# Predict the median value using the Ridge regression model
ridge_pred <- boston_df %>% fit_ridge_regression(., x_vars = c("rm", "lstat"), 
                                                 y_var = "medv", lambda = 0.1) %>% 
  predict_ridge_regression(data = boston_df,.,x_vars = c("rm","lstat"))

# Print the first six predicted values
head(ridge_pred)

## -----------------------------------------------------------------------------
# Fit the Lasso regression using the function
fit <- boston_df %>%  fit_lasso_regression(., x_vars = colnames(boston_df)[1:13], 
                                           y_var = "medv", lambda = 0.1)

# Print the coefficients
fit$coefficients

#Print the intercept
fit$intercept

## -----------------------------------------------------------------------------
# Make predictions using the fitted model
lasso_pred <- boston_df %>% fit_lasso_regression(., x_vars = colnames(boston_df)[1:13], 
                                                 y_var = "medv", lambda = 0.1) %>% 
  predict_lasso_regression(fit = ., new_data = boston_df, 
                           x_vars = colnames(boston_df)[1:13])

# Print the first 10 predicted values
head(lasso_pred, n = 10)

## -----------------------------------------------------------------------------
# Fit a polynomial regression model
poly_fit <- boston_df %>% fit_polynomial_regression(., x_vars = c("age", "rm", "lstat"), 
                                                    y_var = "medv", degree = 2)

# Print the fitted coefficients
poly_fit$coefficients

#Print the first 10 design matrix
head(poly_fit$design_matrix, n = 10)

## -----------------------------------------------------------------------------
# Create new data with lstat and age values
new_data <- data.frame(lstat = c(5.0, 10.0), age = c(50, 60))

# Predict the response variable using the fitted model
predictions <- boston_df %>% fit_polynomial_regression(., x_vars = c("lstat", "age"), 
                                                       y_var = "medv", degree = 2) %>% 
  predict_polynomial_regression(model = ., new_data = new_data, 
                                x_vars = c("lstat", "age"), degree = 2)

# Print the predictions
predictions

## -----------------------------------------------------------------------------
# Split the data into training and test sets
set.seed(123)
train_indices <- sample(1:nrow(boston_df), 0.7 * nrow(boston_df))
train_data <- boston_df[train_indices, ]
test_data <- boston_df[-train_indices, ]

# Make predictions using the KNN regression model
predictions <- train_data %>% predict_knn_regression(., x_vars=colnames(train_data)[-14], 
                                                     y_var="medv", new_data=test_data[, -14], k=5)

# The first 10 predicted values
head(predictions, n = 10)

## -----------------------------------------------------------------------------
# Predict using the fitted model
predictions = boston_df %>% fit_linear_regression(., x_vars = c("age", "rm", "lstat"), y_var = "medv") %>% 
  predict_linear_regression(data = boston_df, lm_fit = .,x_vars = c("age", "rm", "lstat"))


# Create a scatterplot of actual vs. predicted values using the plot_y_actual_vs_predicted function
actual_vs_pred_plot <- plot_y_actual_vs_predicted(boston_df[["medv"]], predictions , "Linear Regression")
actual_vs_pred_plot

## -----------------------------------------------------------------------------
# Make predictions using the fitted model
lasso_pred <- boston_df %>% fit_lasso_regression(., x_vars = colnames(boston_df)[1:13], y_var = "medv", lambda = 0.1) %>% 
  predict_lasso_regression(fit = ., new_data = boston_df, x_vars = colnames(boston_df)[1:13])

# Plot the actual vs. predicted values
lasso_plot <- plot_y_actual_vs_predicted(y_actual = boston_df[, "medv"], y_pred = predictions, model_name = "Lasso Regression")
print(lasso_plot)

## -----------------------------------------------------------------------------
# Split the data into training and test sets
set.seed(123)
train_indices <- sample(1:nrow(boston_df), 0.7 * nrow(boston_df))
train_data <- boston_df[train_indices, ]
test_data <- boston_df[-train_indices, ]

# Make predictions using the KNN regression model
predictions <- predict_knn_regression(train_data, x_vars=colnames(train_data)[-14], y_var="medv", new_data=test_data[, -14], k=5)

# Calculate the MSE
calc_mse(test_data[["medv"]], predictions)

## -----------------------------------------------------------------------------
#define the predictor variables and response variables
x_vars <- c("age", "rm", "tax", "lstat")
y_var <- "medv"

#Split the data into training and testing sets
set.seed(123)
train_indices <- sample(seq_len(nrow(boston_df)), size = 0.8 * nrow(boston_df))
train_data <- boston_df[train_indices, ]
test_data <- boston_df[-train_indices, ]

#Compare the regression models using the `compare_regression_models()` function
results <- train_data %>%
  compare_regression_models(
    x_vars = x_vars,
    y_var = y_var,
    new_data = test_data,
    lambda = 1,
    alpha = 1,
    max_iter = 1000,
    tol = 1e-4,
    degree = 2,
    k = 5
  )

#Display the result
results

